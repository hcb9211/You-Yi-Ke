## about
KeymapManager plugin can manage all plugins keymap what user installed.
## how to use
view -> Keymap Manager or ctrl+alt+K
